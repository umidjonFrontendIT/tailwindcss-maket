"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Progress } from "@/components/ui/progress"
import { CheckCircle, XCircle, RotateCcw, User, Award, Eye, EyeOff, Code2 } from "lucide-react"

interface Question {
  id: number
  question: string
  options: string[]
  correctAnswer: number
  explanation: string
}

const questions: Question[] = [
  {
    id: 1,
    question: "HTML ning to'liq nomi nima?",
    options: [
      "HyperText Markup Language",
      "High Tech Modern Language",
      "Home Tool Markup Language",
      "Hyperlink and Text Markup Language",
    ],
    correctAnswer: 0,
    explanation:
      "HTML - HyperText Markup Language degan ma'noni anglatadi va veb-sahifalar yaratish uchun standart markup tilidir.",
  },
  {
    id: 2,
    question: "HTML hujjatining eng birinchi qatori nima bo'lishi kerak?",
    options: ["<html>", "<head>", "<!DOCTYPE html>", "<title>"],
    correctAnswer: 2,
    explanation: "<!DOCTYPE html> deklaratsiyasi HTML5 hujjatining eng birinchi qatori bo'lishi kerak.",
  },
  {
    id: 3,
    question: "CSS ning to'liq nomi nima?",
    options: ["Computer Style Sheets", "Cascading Style Sheets", "Creative Style Sheets", "Colorful Style Sheets"],
    correctAnswer: 1,
    explanation: "CSS - Cascading Style Sheets degan ma'noni anglatadi va HTML elementlarini bezash uchun ishlatiladi.",
  },
  {
    id: 4,
    question: "HTML da sarlavha teglari nechta va qaysilar?",
    options: [
      "5 ta: <h1> dan <h5> gacha",
      "6 ta: <h1> dan <h6> gacha",
      "4 ta: <h1> dan <h4> gacha",
      "8 ta: <h1> dan <h8> gacha",
    ],
    correctAnswer: 1,
    explanation: "HTML da 6 ta sarlavha tegi mavjud: <h1>, <h2>, <h3>, <h4>, <h5>, <h6>. <h1> eng katta.",
  },
  {
    id: 5,
    question: "CSS da matn rangini o'zgartirish uchun qaysi xususiyat ishlatiladi?",
    options: ["text-color", "font-color", "color", "text-style"],
    correctAnswer: 2,
    explanation: "'color' xususiyati matn rangini belgilash uchun ishlatiladi.",
  },
  {
    id: 6,
    question: "HTML da matnni qalin (bold) qilish uchun qaysi teglar ishlatiladi?",
    options: ["Faqat <b>", "Faqat <strong>", "<b> va <strong> ikkalasi ham", "<bold> va <thick>"],
    correctAnswer: 2,
    explanation: "<b> va <strong> ikkalasi ham matnni qalin qiladi. <strong> semantic ma'noga ega (muhim matn).",
  },
  {
    id: 7,
    question: "CSS da elementning fon rangini o'rnatish uchun qaysi xususiyat ishlatiladi?",
    options: ["bg-color", "background-color", "color-background", "back-color"],
    correctAnswer: 1,
    explanation: "background-color xususiyati elementning fon rangini belgilash uchun ishlatiladi.",
  },
  {
    id: 8,
    question: "HTML da rasm qo'shish uchun qaysi teg va majburiy atribut ishlatiladi?",
    options: [
      "<image> tegi va url atributi",
      "<img> tegi va src atributi",
      "<picture> tegi va href atributi",
      "<photo> tegi va link atributi",
    ],
    correctAnswer: 1,
    explanation: "<img> tegi va src atributi rasm qo'shish uchun ishlatiladi. src atributi rasm manzilini ko'rsatadi.",
  },
  {
    id: 9,
    question: "CSS da matnni markazlashtirish uchun qaysi xususiyat va qiymat ishlatiladi?",
    options: ["align: center", "text-align: center", "center: true", "position: center"],
    correctAnswer: 1,
    explanation: "text-align: center xususiyati matnni gorizontal markazlashtirish uchun ishlatiladi.",
  },
  {
    id: 10,
    question: "HTML da havola yaratish uchun qaysi teg va atribut ishlatiladi?",
    options: [
      "<link> tegi va url atributi",
      "<a> tegi va href atributi",
      "<url> tegi va link atributi",
      "<href> tegi va src atributi",
    ],
    correctAnswer: 1,
    explanation: "<a> (anchor) tegi va href atributi havola yaratish uchun ishlatiladi.",
  },
  {
    id: 11,
    question: "CSS da elementning kengligini belgilash uchun qaysi xususiyat ishlatiladi?",
    options: ["size", "width", "length", "dimension"],
    correctAnswer: 1,
    explanation: "width xususiyati elementning kengligini piksel, foiz yoki boshqa birliklarda belgilaydi.",
  },
  {
    id: 12,
    question: "HTML da tartibsiz ro'yxat yaratish uchun qaysi teglar ishlatiladi?",
    options: ["<ol> va <li>", "<ul> va <li>", "<list> va <item>", "<menu> va <option>"],
    correctAnswer: 1,
    explanation: "<ul> tartibsiz ro'yxat yaratadi, <li> har bir ro'yxat elementi uchun ishlatiladi.",
  },
  {
    id: 13,
    question: "CSS da shrift o'lchamini o'zgartirish uchun qaysi xususiyat ishlatiladi?",
    options: ["text-size", "font-size", "size", "text-scale"],
    correctAnswer: 1,
    explanation: "font-size xususiyati matn shriftining o'lchamini belgilaydi.",
  },
  {
    id: 14,
    question: "HTML da jadval yaratish uchun asosiy teglar qaysilar?",
    options: ["<table>, <row>, <cell>", "<table>, <tr>, <td>", "<grid>, <row>, <column>", "<table>, <line>, <data>"],
    correctAnswer: 1,
    explanation: "<table> jadval, <tr> (table row) qator, <td> (table data) katak yaratish uchun ishlatiladi.",
  },
  {
    id: 15,
    question: "CSS da elementni butunlay yashirish uchun qaysi xususiyat va qiymat ishlatiladi?",
    options: ["hide: true", "visible: false", "display: none", "show: false"],
    correctAnswer: 2,
    explanation: "display: none elementi butunlay yashiradi va u joy egallmaydi.",
  },
  {
    id: 16,
    question: "HTML da forma yaratish uchun qaysi teg ishlatiladi?",
    options: ["<form>", "<input>", "<field>", "<data>"],
    correctAnswer: 0,
    explanation: "<form> tegi forma yaratish uchun ishlatiladi va barcha forma elementlarini o'z ichiga oladi.",
  },
  {
    id: 17,
    question: "CSS da elementning balandligini belgilash uchun qaysi xususiyat ishlatiladi?",
    options: ["length", "height", "size", "tall"],
    correctAnswer: 1,
    explanation: "height xususiyati elementning balandligini belgilaydi.",
  },
  {
    id: 18,
    question: "HTML da matn kiritish maydoni yaratish uchun qaysi kod ishlatiladi?",
    options: ["<text>", "<input type='text'>", "<field type='text'>", "<textbox>"],
    correctAnswer: 1,
    explanation: "<input type='text'> matn kiritish maydoni yaratish uchun ishlatiladi.",
  },
  {
    id: 19,
    question: "CSS da elementning atrofiga chegara qo'yish uchun qaysi xususiyat ishlatiladi?",
    options: ["border", "edge", "outline", "frame"],
    correctAnswer: 0,
    explanation: "border xususiyati elementning atrofiga chegara qo'yish uchun ishlatiladi.",
  },
  {
    id: 20,
    question: "HTML5 da video qo'shish uchun qaysi teg ishlatiladi?",
    options: ["<movie>", "<video>", "<media>", "<film>"],
    correctAnswer: 1,
    explanation: "<video> tegi HTML5 da video fayllarni qo'shish uchun ishlatiladi.",
  },
  {
    id: 21,
    question: "CSS da shrift turini o'zgartirish uchun qaysi xususiyat ishlatiladi?",
    options: ["text-font", "font-family", "font-type", "text-style"],
    correctAnswer: 1,
    explanation: "font-family xususiyati shrift turini (Arial, Times, etc.) belgilaydi.",
  },
  {
    id: 22,
    question: "HTML da matnni kursiv qilish uchun qaysi teglar ishlatiladi?",
    options: ["<i> va <em>", "Faqat <italic>", "Faqat <i>", "<cursive> va <slant>"],
    correctAnswer: 0,
    explanation: "<i> va <em> teglari matnni kursiv qiladi. <em> semantic ma'noga ega (ta'kidlangan matn).",
  },
  {
    id: 23,
    question: "CSS da elementning ichki bo'shliqini belgilash uchun qaysi xususiyat ishlatiladi?",
    options: ["padding", "margin", "spacing", "gap"],
    correctAnswer: 0,
    explanation: "padding elementning ichki bo'shliqini (kontent va chegara orasidagi masofa) belgilaydi.",
  },
  {
    id: 24,
    question: "HTML da dropdown ro'yxat yaratish uchun qaysi teglar ishlatiladi?",
    options: ["<dropdown> va <item>", "<select> va <option>", "<list> va <choice>", "<menu> va <item>"],
    correctAnswer: 1,
    explanation: "<select> dropdown yaratadi, <option> har bir tanlov variantini belgilaydi.",
  },
  {
    id: 25,
    question: "CSS da elementning tashqi bo'shliqini belgilash uchun qaysi xususiyat ishlatiladi?",
    options: ["padding", "margin", "spacing", "border"],
    correctAnswer: 1,
    explanation: "margin elementning tashqi bo'shliqini (boshqa elementlar bilan orasidagi masofa) belgilaydi.",
  },
  {
    id: 26,
    question: "HTML da ko'p qatorli matn kiritish uchun qaysi teg ishlatiladi?",
    options: ["<input type='multiline'>", "<textarea>", "<textbox>", "<multitext>"],
    correctAnswer: 1,
    explanation: "<textarea> ko'p qatorli matn kiritish uchun ishlatiladi.",
  },
  {
    id: 27,
    question: "CSS da elementni aylantirish uchun qaysi xususiyat va funksiya ishlatiladi?",
    options: ["rotate: 45deg", "transform: rotate(45deg)", "turn: 45deg", "spin: 45deg"],
    correctAnswer: 1,
    explanation: "transform: rotate(45deg) elementi belgilangan burchakka aylantiradi.",
  },
  {
    id: 28,
    question: "HTML da checkbox yaratish uchun qaysi kod ishlatiladi?",
    options: ["<input type='check'>", "<input type='checkbox'>", "<checkbox>", "<input type='tick'>"],
    correctAnswer: 1,
    explanation: "<input type='checkbox'> belgilash katakchasi (checkbox) yaratish uchun ishlatiladi.",
  },
  {
    id: 29,
    question: "CSS da elementning joylashuvini boshqarish uchun qaysi xususiyat ishlatiladi?",
    options: ["location", "position", "place", "layout"],
    correctAnswer: 1,
    explanation: "position xususiyati (static, relative, absolute, fixed) elementning joylashuvini boshqaradi.",
  },
  {
    id: 30,
    question: "HTML5 da audio fayl qo'shish uchun qaysi teg ishlatiladi?",
    options: ["<sound>", "<music>", "<audio>", "<voice>"],
    correctAnswer: 2,
    explanation: "<audio> tegi HTML5 da audio fayllarni qo'shish va boshqarish uchun ishlatiladi.",
  },
  {
    id: 31,
    question: "CSS da matnni pastki chiziq bilan bezash uchun qaysi kod ishlatiladi?",
    options: [
      "text-decoration: underline",
      "text-style: underline",
      "font-decoration: underline",
      "border-bottom: 1px solid",
    ],
    correctAnswer: 0,
    explanation: "text-decoration: underline matnni pastki chiziq bilan bezaydi.",
  },
  {
    id: 32,
    question: "HTML da radio button yaratish uchun qaysi kod ishlatiladi?",
    options: ["<input type='radio'>", "<input type='circle'>", "<radio>", "<input type='round'>"],
    correctAnswer: 0,
    explanation: "<input type='radio'> radio tugma yaratadi, bir guruhdan faqat bittasini tanlash mumkin.",
  },
  {
    id: 33,
    question: "CSS da elementni shaffof qilish uchun qaysi xususiyat ishlatiladi?",
    options: ["transparency", "opacity", "alpha", "visible"],
    correctAnswer: 1,
    explanation: "opacity xususiyati 0 (butunlay shaffof) dan 1 (butunlay ko'rinadigan) gacha qiymat oladi.",
  },
  {
    id: 34,
    question: "HTML da matnni belgilash uchun qaysi teg ishlatiladi?",
    options: ["<mark>", "<highlight>", "<select>", "<focus>"],
    correctAnswer: 0,
    explanation: "<mark> tegi HTML5 da matnni belgilash (sariq fon bilan) uchun ishlatiladi.",
  },
  {
    id: 35,
    question: "CSS Flexbox yoqish uchun qaysi kod ishlatiladi?",
    options: ["display: flexbox", "display: flex", "layout: flex", "position: flex"],
    correctAnswer: 1,
    explanation: "display: flex konteynerda flexbox layoutini yoqadi.",
  },
  {
    id: 36,
    question: "HTML da jadval sarlavhasi uchun qaysi teg ishlatiladi?",
    options: ["<th>", "<header>", "<title>", "<caption>"],
    correctAnswer: 0,
    explanation: "<th> (table header) jadval sarlavha katagi uchun ishlatiladi va avtomatik qalin ko'rinadi.",
  },
  {
    id: 37,
    question: "CSS Grid layoutini yoqish uchun qaysi kod ishlatiladi?",
    options: ["display: grid", "layout: grid", "position: grid", "type: grid"],
    correctAnswer: 0,
    explanation: "display: grid konteynerda CSS Grid layoutini yoqadi.",
  },
  {
    id: 38,
    question: "HTML da yuqori indeks yaratish uchun qaysi teg ishlatiladi?",
    options: ["<sup>", "<upper>", "<top>", "<high>"],
    correctAnswer: 0,
    explanation: "<sup> tegi matnni yuqori indeks sifatida (masalan, x²) ko'rsatish uchun ishlatiladi.",
  },
  {
    id: 39,
    question: "CSS da hover effekti qo'shish uchun qaysi selector ishlatiladi?",
    options: [":hover", ":mouseover", ":focus", ":active"],
    correctAnswer: 0,
    explanation: ":hover pseudo-selector sichqoncha elementi ustiga kelganda ishga tushadi.",
  },
  {
    id: 40,
    question: "HTML da pastki indeks yaratish uchun qaysi teg ishlatiladi?",
    options: ["<sub>", "<lower>", "<bottom>", "<down>"],
    correctAnswer: 0,
    explanation: "<sub> tegi matnni pastki indeks sifatida (masalan, H₂O) ko'rsatadi.",
  },
  {
    id: 41,
    question: "CSS da animatsiya yaratish uchun qaysi xususiyat ishlatiladi?",
    options: ["animation", "transition", "motion", "effect"],
    correctAnswer: 0,
    explanation: "animation xususiyati murakkab CSS animatsiyalarini yaratish uchun ishlatiladi.",
  },
  {
    id: 42,
    question: "HTML da kod namunasini ko'rsatish uchun qaysi teg ishlatiladi?",
    options: ["<code>", "<pre>", "<script>", "<program>"],
    correctAnswer: 0,
    explanation: "<code> tegi kod qismlarini monospace shriftda ko'rsatish uchun ishlatiladi.",
  },
  {
    id: 43,
    question: "CSS da z-index xususiyati nima uchun ishlatiladi?",
    options: [
      "Elementning kengligini belgilash",
      "Elementning balandligini belgilash",
      "Elementlarning qatlamini belgilash",
      "Elementning rangini belgilash",
    ],
    correctAnswer: 2,
    explanation: "z-index elementlarning qatlam tartibini belgilaydi (qaysi biri ustida turadi).",
  },
  {
    id: 44,
    question: "HTML da parol kiritish maydoni yaratish uchun qaysi kod ishlatiladi?",
    options: ["<input type='password'>", "<input type='secret'>", "<password>", "<input type='hidden'>"],
    correctAnswer: 0,
    explanation: "<input type='password'> parol kiritish maydoni yaratadi va kiritilgan matn yashirinadi.",
  },
  {
    id: 45,
    question: "CSS da matnni katta harflarga aylantirish uchun qaysi kod ishlatiladi?",
    options: ["text-transform: uppercase", "text-case: upper", "font-case: capital", "text-style: caps"],
    correctAnswer: 0,
    explanation: "text-transform: uppercase barcha harflarni katta harflarga aylantiradi.",
  },
  {
    id: 46,
    question: "HTML da qisqa iqtibos uchun qaysi teg ishlatiladi?",
    options: ["<quote>", "<q>", "<cite>", "<blockquote>"],
    correctAnswer: 1,
    explanation: "<q> tegi qisqa iqtiboslar uchun, <blockquote> uzun iqtiboslar uchun ishlatiladi.",
  },
  {
    id: 47,
    question: "CSS da sichqoncha ko'rinishini o'zgartirish uchun qaysi xususiyat ishlatiladi?",
    options: ["mouse", "cursor", "pointer", "hover"],
    correctAnswer: 1,
    explanation: "cursor xususiyati sichqoncha ko'rinishini (pointer, text, wait, etc.) o'zgartiradi.",
  },
  {
    id: 48,
    question: "HTML da meta ma'lumotlar qayerda joylashadi?",
    options: ["<body> ichida", "<head> ichida", "<html> ichida", "<title> ichida"],
    correctAnswer: 1,
    explanation: "<meta> tegi <head> bo'limida joylashadi va sahifa haqida ma'lumot beradi.",
  },
  {
    id: 49,
    question: "CSS da elementga soya qo'shish uchun qaysi xususiyat ishlatiladi?",
    options: ["shadow", "box-shadow", "element-shadow", "drop-shadow"],
    correctAnswer: 1,
    explanation: "box-shadow elementga soya effekti qo'shish uchun ishlatiladi.",
  },
  {
    id: 50,
    question: "HTML5 da semantic element bo'lmagan teg qaysi?",
    options: ["<header>", "<nav>", "<div>", "<footer>"],
    correctAnswer: 2,
    explanation:
      "<div> semantic element emas, faqat umumiy konteyner. <header>, <nav>, <footer> semantic elementlardir.",
  },
  {
    id: 51,
    question: "CSS da matnni kichik harflarga aylantirish uchun qaysi kod ishlatiladi?",
    options: ["text-transform: lowercase", "text-case: lower", "font-case: small", "text-style: lower"],
    correctAnswer: 0,
    explanation: "text-transform: lowercase barcha harflarni kichik harflarga aylantiradi.",
  },
  {
    id: 52,
    question: "HTML da tartibli ro'yxat yaratish uchun qaysi teg ishlatiladi?",
    options: ["<ul>", "<ol>", "<li>", "<order>"],
    correctAnswer: 1,
    explanation: "<ol> (ordered list) tartibli ro'yxat yaratadi, <li> har bir element uchun ishlatiladi.",
  },
  {
    id: 53,
    question: "CSS da matn shriftini qalin qilish uchun qaysi xususiyat ishlatiladi?",
    options: ["font-weight", "text-bold", "font-style", "text-weight"],
    correctAnswer: 0,
    explanation: "font-weight xususiyati matn shriftini qalin (bold) yoki yupqa qilish uchun ishlatiladi.",
  },
  {
    id: 54,
    question: "HTML da progress bar yaratish uchun qaysi teg ishlatiladi?",
    options: ["<progress>", "<bar>", "<meter>", "<loading>"],
    correctAnswer: 0,
    explanation: "<progress> tegi jarayonning borish holatini ko'rsatish uchun ishlatiladi.",
  },
  {
    id: 55,
    question: "CSS da elementni markazga joylashtirish uchun margin qanday qo'yiladi?",
    options: ["margin: center", "margin: 0 auto", "margin: auto 0", "margin: middle"],
    correctAnswer: 1,
    explanation: "margin: 0 auto elementi gorizontal markazga joylashtiradi.",
  },
  {
    id: 56,
    question: "HTML da matnni chizib tashlash uchun qaysi teg ishlatiladi?",
    options: ["<strike>", "<del>", "<s>", "Barcha javoblar to'g'ri"],
    correctAnswer: 3,
    explanation: "<strike> (eskirgan), <del> (o'chirilgan), <s> (noto'g'ri) teglari matnni chizib tashlaydi.",
  },
  {
    id: 57,
    question: "CSS da elementning maksimal kengligini belgilash uchun qaysi xususiyat ishlatiladi?",
    options: ["max-width", "width-max", "maximum-width", "limit-width"],
    correctAnswer: 0,
    explanation: "max-width elementning maksimal kengligini belgilaydi.",
  },
  {
    id: 58,
    question: "HTML da klaviatura tugmasi ko'rinishini yaratish uchun qaysi teg ishlatiladi?",
    options: ["<key>", "<kbd>", "<keyboard>", "<button>"],
    correctAnswer: 1,
    explanation: "<kbd> tegi klaviatura tugmalarini (Ctrl, Alt, Enter) ko'rsatish uchun ishlatiladi.",
  },
  {
    id: 59,
    question: "CSS da matnni kursiv qilish uchun qaysi xususiyat ishlatiladi?",
    options: ["font-style: italic", "text-style: italic", "font-italic: true", "text-italic: on"],
    correctAnswer: 0,
    explanation: "font-style: italic matnni kursiv qilish uchun ishlatiladi.",
  },
  {
    id: 60,
    question: "HTML da email kiritish maydoni yaratish uchun qaysi kod ishlatiladi?",
    options: ["<input type='email'>", "<input type='mail'>", "<email>", "<input type='e-mail'>"],
    correctAnswer: 0,
    explanation: "<input type='email'> email manzil kiritish uchun maxsus maydon yaratadi.",
  },
  {
    id: 61,
    question: "CSS da elementning minimal balandligini belgilash uchun qaysi xususiyat ishlatiladi?",
    options: ["min-height", "height-min", "minimum-height", "small-height"],
    correctAnswer: 0,
    explanation: "min-height elementning minimal balandligini belgilaydi.",
  },
  {
    id: 62,
    question: "HTML da matnni kichik ko'rsatish uchun qaysi teg ishlatiladi?",
    options: ["<small>", "<tiny>", "<mini>", "<little>"],
    correctAnswer: 0,
    explanation: "<small> tegi matnni kichikroq shriftda ko'rsatish uchun ishlatiladi.",
  },
  {
    id: 63,
    question: "CSS da elementni ko'rinmas qilish (lekin joy egallash) uchun qaysi kod ishlatiladi?",
    options: ["display: none", "visibility: hidden", "opacity: 0", "hide: true"],
    correctAnswer: 1,
    explanation: "visibility: hidden elementi ko'rinmas qiladi lekin u o'z joyini egallaydi.",
  },
  {
    id: 64,
    question: "HTML da raqam kiritish maydoni yaratish uchun qaysi kod ishlatiladi?",
    options: ["<input type='number'>", "<input type='numeric'>", "<number>", "<input type='digit'>"],
    correctAnswer: 0,
    explanation: "<input type='number'> faqat raqamlar kiritish uchun maydon yaratadi.",
  },
  {
    id: 65,
    question: "CSS da matn qatorlari orasidagi masofani belgilash uchun qaysi xususiyat ishlatiladi?",
    options: ["line-height", "text-spacing", "line-spacing", "row-height"],
    correctAnswer: 0,
    explanation: "line-height matn qatorlari orasidagi masofani belgilaydi.",
  },
  {
    id: 66,
    question: "HTML da sana kiritish maydoni yaratish uchun qaysi kod ishlatiladi?",
    options: ["<input type='date'>", "<input type='calendar'>", "<date>", "<input type='day'>"],
    correctAnswer: 0,
    explanation: "<input type='date'> sana tanlash uchun maxsus maydon yaratadi.",
  },
  {
    id: 67,
    question: "CSS da elementning fon rasmini belgilash uchun qaysi xususiyat ishlatiladi?",
    options: ["background-image", "bg-image", "image-background", "back-image"],
    correctAnswer: 0,
    explanation: "background-image elementning fon rasmini belgilash uchun ishlatiladi.",
  },
  {
    id: 68,
    question: "HTML da uzun iqtibos uchun qaysi teg ishlatiladi?",
    options: ["<quote>", "<q>", "<blockquote>", "<longquote>"],
    correctAnswer: 2,
    explanation: "<blockquote> tegi uzun iqtiboslar uchun ishlatiladi va alohida blok yaratadi.",
  },
  {
    id: 69,
    question: "CSS da matnni o'rtaga joylashtirish (vertikal) uchun flexbox da qaysi xususiyat ishlatiladi?",
    options: ["align-items: center", "vertical-align: center", "justify-content: center", "text-align: center"],
    correctAnswer: 0,
    explanation: "align-items: center flexbox konteynerida elementlarni vertikal markazlashtiradi.",
  },
  {
    id: 70,
    question: "HTML da vaqt kiritish maydoni yaratish uchun qaysi kod ishlatiladi?",
    options: ["<input type='time'>", "<input type='clock'>", "<time>", "<input type='hour'>"],
    correctAnswer: 0,
    explanation: "<input type='time'> vaqt kiritish uchun maxsus maydon yaratadi.",
  },
]

export default function HTMLCSSQuizApp() {
  const [userName, setUserName] = useState("")
  const [quizStarted, setQuizStarted] = useState(false)
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null)
  const [showResult, setShowResult] = useState(false)
  const [score, setScore] = useState(0)
  const [answers, setAnswers] = useState<number[]>([])
  const [quizCompleted, setQuizCompleted] = useState(false)
  const [secretKey, setSecretKey] = useState("")
  const [showSecretInput, setShowSecretInput] = useState(false)

  const handleStartQuiz = () => {
    if (userName.trim().length >= 2) {
      setQuizStarted(true)
    }
  }

  const handleAnswerSelect = (answerIndex: number) => {
    setSelectedAnswer(answerIndex)
  }

  const handleNextQuestion = () => {
    if (selectedAnswer === null) return

    const newAnswers = [...answers, selectedAnswer]
    setAnswers(newAnswers)

    if (selectedAnswer === questions[currentQuestion].correctAnswer) {
      setScore(score + 1)
    }

    setShowResult(true)
  }

  const handleContinue = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
      setSelectedAnswer(null)
      setShowResult(false)
    } else {
      setQuizCompleted(true)
    }
  }

  const handleSecretKey = () => {
    if (secretKey.toUpperCase() === "OMAD") {
      resetQuiz()
      setSecretKey("")
      setShowSecretInput(false)
    }
  }

  const resetQuiz = () => {
    setCurrentQuestion(0)
    setSelectedAnswer(null)
    setShowResult(false)
    setScore(0)
    setAnswers([])
    setQuizCompleted(false)
    setQuizStarted(false)
    setUserName("")
  }

  const getScoreColor = () => {
    const percentage = (score / questions.length) * 100
    if (percentage >= 80) return "text-yellow-400"
    if (percentage >= 60) return "text-yellow-600"
    return "text-red-400"
  }

  const getScoreMessage = () => {
    const percentage = (score / questions.length) * 100
    if (percentage >= 90) return "🏆 Mukammal! Siz HTML va CSS ustasi!"
    if (percentage >= 80) return "🥇 A'lo! Juda yaxshi natija!"
    if (percentage >= 70) return "🥈 Yaxshi! Biroz amaliyot qiling."
    if (percentage >= 60) return "🥉 O'rtacha. Ko'proq o'rganing."
    return "📚 Ko'proq o'rganish kerak."
  }

  // Ism kirish sahifasi
  if (!quizStarted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-800 flex items-center justify-center p-4">
        <div className="absolute inset-0 bg-[url('/placeholder.svg?height=1080&width=1920')] opacity-5"></div>
        <Card className="w-full max-w-md shadow-2xl border-yellow-400/20 bg-black/80 backdrop-blur-sm">
          <CardHeader className="text-center bg-gradient-to-r from-yellow-400 to-yellow-600 text-black rounded-t-lg">
            <div className="flex justify-center mb-4">
              <Code2 className="w-12 h-12" />
            </div>
            <CardTitle className="text-2xl font-bold">HTML & CSS Quiz</CardTitle>
            <p className="text-sm opacity-90">70 ta savol • Kengaytirilgan test</p>
          </CardHeader>
          <CardContent className="p-8">
            <div className="space-y-6">
              <div className="text-center text-gray-300">
                <h3 className="text-lg font-semibold mb-2 text-yellow-400">Bilimingizni chuqur sinang!</h3>
                <p className="text-sm">
                  HTML va CSS bo'yicha 70 ta savol. Teglar, xususiyatlar, layoutlar va zamonaviy texnikalar.
                </p>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    <User className="w-4 h-4 inline mr-2" />
                    Ismingiz
                  </label>
                  <Input
                    type="text"
                    placeholder="Ismingizni kiriting"
                    value={userName}
                    onChange={(e) => setUserName(e.target.value)}
                    className="bg-gray-800 border-gray-600 text-white placeholder-gray-400 focus:border-yellow-400"
                  />
                </div>

                <Button
                  onClick={handleStartQuiz}
                  disabled={userName.trim().length < 2}
                  className="w-full bg-gradient-to-r from-yellow-400 to-yellow-600 hover:from-yellow-500 hover:to-yellow-700 text-black font-semibold py-3 text-lg transition-all duration-300 transform hover:scale-105"
                >
                  70 Savolli Quizni boshlash
                </Button>
              </div>

              <div className="text-xs text-gray-400 text-center">
                <p>• 70 ta HTML va CSS savoli</p>
                <p>• Asosiy va ilg'or mavzular</p>
                <p>• Har bir javob uchun tushuntirish</p>
                <p>• Natijalar oxirida batafsil ko'rsatiladi</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  // Quiz yakunlangan sahifa
  if (quizCompleted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-800 p-4">
        <div className="absolute inset-0 bg-[url('/placeholder.svg?height=1080&width=1920')] opacity-10"></div>
        <div className="max-w-4xl mx-auto">
          <Card className="shadow-2xl border-yellow-400/30 bg-black/90 backdrop-blur-sm">
            <CardHeader className="text-center bg-gradient-to-r from-yellow-400 to-yellow-600 text-black rounded-t-lg">
              <div className="flex justify-center mb-4">
                <Award className="w-20 h-20 animate-pulse" />
              </div>
              <CardTitle className="text-4xl font-bold">70 Savolli Quiz Yakunlandi!</CardTitle>
              <p className="text-lg opacity-90">Tabriklaymiz! Siz barcha savollarni tugatdingiz</p>
            </CardHeader>
            <CardContent className="p-8">
              <div className="text-center mb-8">
                <div className="mb-6">
                  <div className={`text-8xl font-bold mb-4 ${getScoreColor()}`}>
                    {score}/{questions.length}
                  </div>
                  <div className={`text-4xl font-semibold mb-4 ${getScoreColor()}`}>
                    {Math.round((score / questions.length) * 100)}%
                  </div>
                  <p className="text-2xl text-gray-300 mb-6">{getScoreMessage()}</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                  <div className="bg-gradient-to-br from-green-900/50 to-green-800/30 p-6 rounded-xl border border-green-400/30">
                    <CheckCircle className="w-12 h-12 text-green-400 mx-auto mb-3" />
                    <div className="text-3xl font-bold text-green-400">{score}</div>
                    <div className="text-sm text-green-300">To'g'ri javoblar</div>
                  </div>
                  <div className="bg-gradient-to-br from-red-900/50 to-red-800/30 p-6 rounded-xl border border-red-400/30">
                    <XCircle className="w-12 h-12 text-red-400 mx-auto mb-3" />
                    <div className="text-3xl font-bold text-red-400">{questions.length - score}</div>
                    <div className="text-sm text-red-300">Noto'g'ri javoblar</div>
                  </div>
                  <div className="bg-gradient-to-br from-yellow-900/50 to-yellow-800/30 p-6 rounded-xl border border-yellow-400/30">
                    <User className="w-12 h-12 text-yellow-400 mx-auto mb-3" />
                    <div className="text-lg font-bold text-yellow-400 truncate">{userName}</div>
                    <div className="text-sm text-yellow-300">Web Developer</div>
                  </div>
                </div>

                <div className="bg-gradient-to-r from-blue-900/30 to-blue-800/20 p-6 rounded-xl border border-blue-400/30 mb-8">
                  <h3 className="text-xl font-bold text-blue-400 mb-4">📊 Batafsil natijalar</h3>
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-4 text-sm">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-400">
                        {Math.round((score / questions.length) * 100)}%
                      </div>
                      <div className="text-gray-400">Umumiy ball</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-blue-400">{score}</div>
                      <div className="text-gray-400">To'g'ri</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-red-400">{questions.length - score}</div>
                      <div className="text-gray-400">Noto'g'ri</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-yellow-400">{questions.length}</div>
                      <div className="text-gray-400">Jami</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-purple-400">
                        {score >= 56 ? "A'lo" : score >= 42 ? "Yaxshi" : score >= 28 ? "O'rta" : "Past"}
                      </div>
                      <div className="text-gray-400">Daraja</div>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                  <Button
                    onClick={resetQuiz}
                    className="bg-gradient-to-r from-yellow-400 to-yellow-600 hover:from-yellow-500 hover:to-yellow-700 text-black font-semibold px-8 py-4 text-lg transition-all duration-300 transform hover:scale-105"
                  >
                    <RotateCcw className="w-5 h-5 mr-2" />
                    Qaytadan boshlash
                  </Button>

                  <Button
                    onClick={() => setShowSecretInput(!showSecretInput)}
                    variant="outline"
                    className="border-gray-600 text-gray-400 hover:text-white hover:border-gray-500"
                  >
                    {showSecretInput ? <EyeOff className="w-4 h-4 mr-2" /> : <Eye className="w-4 h-4 mr-2" />}
                    {showSecretInput ? "Yashirish" : "Maxfiy kalit"}
                  </Button>
                </div>

                {showSecretInput && (
                  <div className="mt-6 max-w-sm mx-auto">
                    <div className="flex gap-2">
                      <Input
                        type="password"
                        placeholder="Maxfiy kalitni kiriting"
                        value={secretKey}
                        onChange={(e) => setSecretKey(e.target.value)}
                        className="bg-gray-800 border-gray-600 text-white placeholder-gray-400"
                        onKeyPress={(e) => e.key === "Enter" && handleSecretKey()}
                      />
                      <Button onClick={handleSecretKey} className="bg-red-600 hover:bg-red-700 text-white">
                        OK
                      </Button>
                    </div>
                    <p className="text-xs text-gray-500 mt-2">Natijalarni yashirish uchun maxfiy kalitni kiriting</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  // Quiz sahifasi
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-800 p-4">
      <div className="absolute inset-0 bg-[url('/placeholder.svg?height=1080&width=1920')] opacity-5"></div>
      <div className="max-w-4xl mx-auto relative z-10">
        <div className="mb-6">
          <div className="flex justify-between items-center mb-4">
            <h1 className="text-3xl font-bold bg-gradient-to-r from-yellow-400 to-yellow-600 bg-clip-text text-transparent">
              HTML & CSS Quiz
            </h1>
            <div className="text-lg font-semibold text-yellow-400 bg-black/50 px-4 py-2 rounded-lg border border-yellow-400/30">
              Ball: {score}/{currentQuestion + (showResult ? 1 : 0)}
            </div>
          </div>
          <Progress
            value={((currentQuestion + 1) / questions.length) * 100}
            className="h-4 bg-gray-800 border border-gray-700"
          />
          <div className="text-sm text-gray-400 mt-2 flex justify-between">
            <span>
              Savol {currentQuestion + 1} / {questions.length}
            </span>
            <span className="text-yellow-400">{userName}</span>
          </div>
        </div>

        <Card className="shadow-2xl border-yellow-400/20 bg-black/80 backdrop-blur-sm">
          <CardHeader className="bg-gradient-to-r from-gray-800 to-gray-900 text-white border-b border-yellow-400/20">
            <CardTitle className="text-xl text-yellow-400 flex items-center">
              <Code2 className="w-6 h-6 mr-2" />
              {questions[currentQuestion].question}
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            {!showResult ? (
              <div className="space-y-4">
                {questions[currentQuestion].options.map((option, index) => (
                  <button
                    key={index}
                    onClick={() => handleAnswerSelect(index)}
                    className={`w-full p-4 text-left rounded-xl border-2 transition-all duration-300 transform hover:scale-[1.02] ${
                      selectedAnswer === index
                        ? "border-yellow-400 bg-gradient-to-r from-yellow-400/20 to-yellow-600/20 text-yellow-100 shadow-lg shadow-yellow-400/20"
                        : "border-gray-600 bg-gray-800/50 hover:border-gray-500 hover:bg-gray-700/50 text-gray-300"
                    }`}
                  >
                    <span className="font-bold mr-3 text-yellow-400">{String.fromCharCode(65 + index)}.</span>
                    <span className="font-mono text-sm">{option}</span>
                  </button>
                ))}

                <div className="pt-6">
                  <Button
                    onClick={handleNextQuestion}
                    disabled={selectedAnswer === null}
                    className="w-full bg-gradient-to-r from-yellow-400 to-yellow-600 hover:from-yellow-500 hover:to-yellow-700 text-black font-semibold py-4 text-lg transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
                  >
                    Javobni tasdiqlash
                  </Button>
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="flex items-center justify-center mb-6">
                  {selectedAnswer === questions[currentQuestion].correctAnswer ? (
                    <div className="flex items-center text-green-400 bg-green-400/10 px-6 py-3 rounded-xl border border-green-400/30">
                      <CheckCircle className="w-8 h-8 mr-3" />
                      <span className="text-2xl font-bold">To'g'ri!</span>
                    </div>
                  ) : (
                    <div className="flex items-center text-red-400 bg-red-400/10 px-6 py-3 rounded-xl border border-red-400/30">
                      <XCircle className="w-8 h-8 mr-3" />
                      <span className="text-2xl font-bold">Noto'g'ri!</span>
                    </div>
                  )}
                </div>

                <div className="bg-gradient-to-r from-green-900/30 to-green-800/20 p-6 rounded-xl border border-green-400/30">
                  <div className="font-semibold text-green-400 mb-3 flex items-center">
                    <CheckCircle className="w-5 h-5 mr-2" />
                    To'g'ri javob:
                  </div>
                  <div className="text-green-300 font-medium text-lg font-mono">
                    {String.fromCharCode(65 + questions[currentQuestion].correctAnswer)}.{" "}
                    {questions[currentQuestion].options[questions[currentQuestion].correctAnswer]}
                  </div>
                </div>

                <div className="bg-gradient-to-r from-blue-900/30 to-blue-800/20 p-6 rounded-xl border border-blue-400/30">
                  <div className="font-semibold text-blue-400 mb-3 flex items-center">
                    <Code2 className="w-5 h-5 mr-2" />
                    Tushuntirish:
                  </div>
                  <div className="text-blue-300">{questions[currentQuestion].explanation}</div>
                </div>

                <Button
                  onClick={handleContinue}
                  className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-semibold py-4 text-lg transition-all duration-300 transform hover:scale-105"
                >
                  {currentQuestion < questions.length - 1 ? "Keyingi savol" : "Natijalarni ko'rish"}
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
