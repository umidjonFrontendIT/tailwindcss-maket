"use server"

interface QuizResult {
  userEmail: string
  score: number
  totalQuestions: number
  percentage: number
  answers: number[]
}

export async function sendQuizResults(result: QuizResult) {
  try {
    // Bu yerda email yuborish logikasi bo'ladi
    // Haqiqiy loyihada Resend, SendGrid yoki boshqa email service ishlatiladi

    const emailContent = `
      HTML & CSS Quiz Natijalari
      
      Ishtirokchi: ${result.userEmail}
      Ball: ${result.score}/${result.totalQuestions}
      Foiz: ${result.percentage}%
      
      Batafsil natijalar:
      ${result.answers
        .map(
          (answer, index) =>
            `Savol ${index + 1}: ${answer === 0 ? "A" : answer === 1 ? "B" : answer === 2 ? "C" : "D"}`,
        )
        .join("\n")}
      
      Quiz sanasi: ${new Date().toLocaleString("uz-UZ")}
    `

    // Console log orqali natijani ko'rsatamiz (development uchun)
    console.log("Quiz natijalari:", emailContent)

    // Bu yerda real email yuborish kodi bo'ladi:
    /*
    await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.RESEND_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from: 'quiz@yourdomain.com',
        to: 'umannopov368@gmail.com',
        subject: `Quiz Natijalari - ${result.userEmail}`,
        text: emailContent,
      }),
    })
    */

    // Simulatsiya uchun 1 soniya kutamiz
    await new Promise((resolve) => setTimeout(resolve, 1000))

    return { success: true }
  } catch (error) {
    console.error("Email yuborishda xatolik:", error)
    throw new Error("Email yuborishda xatolik yuz berdi")
  }
}
